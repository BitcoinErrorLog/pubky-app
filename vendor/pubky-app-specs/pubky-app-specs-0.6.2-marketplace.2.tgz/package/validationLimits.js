const limits = {
  "maxBlobSizeBytes": 104857600,
  "maxFileSizeBytes": 104857600,
  "tagLabelMinLength": 1,
  "tagLabelMaxLength": 20,
  "tagInvalidChars": [
    ",",
    ":",
    " ",
    "\t",
    "\n",
    "\r"
  ],
  "userNameMinLength": 3,
  "userNameMaxLength": 50,
  "userBioMaxLength": 160,
  "userImageUrlMaxLength": 300,
  "userLinksMaxCount": 5,
  "userLinkTitleMaxLength": 100,
  "userLinkUrlMaxLength": 300,
  "userStatusMaxLength": 50,
  "postShortContentMaxLength": 2000,
  "postLongContentMaxLength": 50000,
  "postAttachmentsMaxCount": 10,
  "postAttachmentUrlMaxLength": 200,
  "postAllowedAttachmentProtocols": [
    "pubky",
    "http",
    "https"
  ],
  "collectionContentMaxLength": 40000,
  "collectionNameMinLength": 1,
  "collectionNameMaxLength": 100,
  "collectionDescriptionMaxLength": 500,
  "collectionItemsMaxCount": 100,
  "fileNameMinLength": 1,
  "fileNameMaxLength": 255,
  "fileSrcMaxLength": 1024,
  "feedTagsMaxCount": 5
};

export const validationLimits = limits;
export const getValidationLimits = () => JSON.parse(JSON.stringify(limits));
export default limits;
