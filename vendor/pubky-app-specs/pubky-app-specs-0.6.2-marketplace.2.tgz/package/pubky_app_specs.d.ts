/* tslint:disable */
/* eslint-disable */
/**
 * Creator-chosen default layout for experiencing a collection.
 *
 * Unrecognized values deserialize as `Unknown` so future layouts never
 * invalidate the whole post (same policy as `PubkyAppPostKind`).
 */
export type PubkyAppCollectionLayout = "grid" | "list" | "visual" | "unknown";

/**
 * Typed JSON envelope stored in `PubkyAppPost::content` when `kind == Collection`.
 *
 * A collection post curates an ordered list of URIs (via `items`)
 * under a `name` and optional `description`. The envelope is parsed and validated
 * by the spec but never re-serialized as a top-level homeserver object.
 *
 * **Construction**: this struct is deserialized from the post\'s `content` JSON
 * envelope during validation and is **not** intended to be constructed by
 * callers directly. It is re-exported publicly (via `lib.rs`) so SDK consumers
 * can inspect the envelope shape (OpenAPI schema, type definitions), but the
 * authoritative way to produce a Collection post is to author a `PubkyAppPost`
 * with `kind: Collection` and a `content` string that JSON-parses into this
 * shape.
 *
 * Forward-compat: `#[serde(deny_unknown_fields)]` is intentionally NOT used so
 * future minor versions can add fields (e.g. `cover_image`) without breaking
 * older parsers. New fields must be additive and ignorable.
 */
export interface PubkyAppCollectionContent {
    /**
     * Display name of the collection. Length bounded by
     * `VALIDATION_LIMITS.collection_name_{min,max}_length` (unicode scalars).
     * Whitespace-only names are rejected separately by the validator.
     */
    name: string;
    /**
     * Optional human-readable description. Length bounded by
     * `VALIDATION_LIMITS.collection_description_max_length` (unicode scalars).
     */
    description?: string;
    /**
     * Ordered list of URIs this collection curates: canonical Post URIs
     * and/or canonical marketplace Listing URIs. Count bounded by
     * `VALIDATION_LIMITS.collection_items_max_count`; each URI must be in
     * exact canonical form (see `validate_collection_item_uri`).
     */
    items?: string[];
    /**
     * Optional hero/cover image URL. Length bounded by
     * `VALIDATION_LIMITS.post_attachment_url_max_length`; protocol must be in
     * `VALIDATION_LIMITS.post_allowed_attachment_protocols`.
     */
    cover_image?: string;
    /**
     * Creator\'s preferred default layout.
     */
    layout?: PubkyAppCollectionLayout;
}


export class BlobResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly blob: PubkyAppBlob;
    readonly meta: Meta;
}

export class BookmarkResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly bookmark: PubkyAppBookmark;
    readonly meta: Meta;
}

export class FeedResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly feed: PubkyAppFeed;
    readonly meta: Meta;
}

export class FileResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly file: PubkyAppFile;
    readonly meta: Meta;
}

export class FollowResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly follow: PubkyAppFollow;
    readonly meta: Meta;
}

export class LastReadResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly last_read: PubkyAppLastRead;
    readonly meta: Meta;
}

export class ListingResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly listing: PubkyAppListing;
    readonly meta: Meta;
}

export class MarketplaceReviewResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly marketplace_review: PubkyAppMarketplaceReview;
    readonly meta: Meta;
}

export class Meta {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly id: string;
    readonly path: string;
    readonly url: string;
}

export class MuteResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly meta: Meta;
    readonly mute: PubkyAppMute;
}

/**
 * This object represents the result of parsing a Pubky URI. It contains:
 * - `user_id`: the parsed user ID as a string.
 * - `resource`: a string representing the kind of resource (derived from internal `Resource` enum Display).
 * - `resource_id`: an optional resource identifier (if applicable).
 */
export class ParsedUriResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Returns the resource kind.
     */
    readonly resource: string;
    /**
     * Returns the resource ID if present.
     */
    readonly resource_id: string | undefined;
    /**
     * Returns the user ID.
     */
    readonly user_id: string;
}

export class PostResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly meta: Meta;
    readonly post: PubkyAppPost;
}

/**
 * Represents a blob, which backs a file uploaded by the user.
 * URI: /pub/pubky.app/blobs/:blob_id
 */
export class PubkyAppBlob {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyAppBlob;
    toJson(): any;
    /**
     * Getter for the blob data as a `Uint8Array`.
     */
    readonly data: Uint8Array;
}

/**
 * Represents raw homeserver bookmark with id
 * URI: /pub/pubky.app/bookmarks/:bookmark_id
 *
 * Example URI:
 *
 * `/pub/pubky.app/bookmarks/AF7KQ6NEV5XV1EG5DVJ2E74JJ4`
 *
 * Where bookmark_id is Crockford-base32(Blake3("{uri_bookmarked}"")[:half])
 */
export class PubkyAppBookmark {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Serialize to JSON for WASM.
     */
    static fromJson(js_value: any): PubkyAppBookmark;
    toJson(): any;
    created_at: bigint;
    /**
     * Getter for `uri`.
     */
    readonly uri: string;
}

/**
 * Represents a feed configuration.
 */
export class PubkyAppFeed {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Serialize to JSON for WASM.
     */
    static fromJson(js_value: any): PubkyAppFeed;
    toJson(): any;
    created_at: bigint;
    /**
     * Getter for `feed`.
     */
    readonly feed: PubkyAppFeedConfig;
    /**
     * Getter for `name`.
     */
    readonly name: string;
}

/**
 * Configuration object for the feed.
 */
export class PubkyAppFeedConfig {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyAppFeedConfig;
    toJson(): any;
    /**
     * Getter for `content`.
     */
    readonly content: PubkyAppPostKind | undefined;
    /**
     * Getter for `domain_tags`.
     */
    readonly domain_tags: string[] | undefined;
    /**
     * Getter for `layout`.
     */
    readonly layout: PubkyAppFeedLayout;
    /**
     * Getter for `name`.
     */
    readonly reach: PubkyAppFeedReach;
    /**
     * Getter for `sort`.
     */
    readonly sort: PubkyAppFeedSort;
    /**
     * Getter for `tags`.
     */
    readonly tags: string[] | undefined;
}

/**
 * Enum representing the layout of the feed.
 */
export enum PubkyAppFeedLayout {
    Columns = 0,
    Wide = 1,
    Visual = 2,
    List = 3,
}

/**
 * Enum representing the reach of the feed.
 */
export enum PubkyAppFeedReach {
    Following = 0,
    Followers = 1,
    Friends = 2,
    All = 3,
    Wot = 4,
    Me = 5,
}

/**
 * Enum representing the sort order of the feed.
 */
export enum PubkyAppFeedSort {
    Recent = 0,
    Popularity = 1,
}

/**
 * Represents a file uploaded by the user.
 * URI: /pub/pubky.app/files/:file_id
 */
export class PubkyAppFile {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyAppFile;
    toJson(): any;
    created_at: bigint;
    size: number;
    readonly content_type: string;
    readonly name: string;
    readonly src: string;
}

/**
 * Represents raw homeserver follow object with timestamp
 *
 * On follow objects, the main data is encoded in the path
 *
 * URI: /pub/pubky.app/follows/:user_id
 *
 * Example URI:
 *
 * `/pub/pubky.app/follows/pxnu33x7jtpx9ar1ytsi4yxbp6a5o36gwhffs8zoxmbuptici1jy`
 */
export class PubkyAppFollow {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyAppFollow;
    toJson(): any;
    created_at: bigint;
}

/**
 * How the item can be delivered to the buyer.
 */
export enum PubkyAppFulfillmentMethod {
    Physical = 0,
    Digital = 1,
    Pickup = 2,
}

/**
 * Represents the last read timestamp for notifications.
 * URI: /pub/pubky.app/last_read
 */
export class PubkyAppLastRead {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyAppLastRead;
    toJson(): any;
    timestamp: bigint;
}

/**
 * Represents a marketplace listing published by a seller.
 *
 * URI: /pub/pubky.app/marketplace/v1/listings/:listing_id
 *
 * Where listing_id is Crockford-base32 encoding of a timestamp and must
 * match the record's `listingId` field.
 */
export class PubkyAppListing {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyAppListing;
    toJson(): any;
    adult_only: boolean;
    /**
     * Monotonically increasing record revision, starting at 1.
     */
    revision: bigint;
    /**
     * Marketplace contract version, always `1`.
     */
    schema_version: bigint;
    /**
     * Marketplace category taxonomy version, always `1`.
     */
    taxonomy_version: bigint;
    /**
     * Getter for `description`.
     */
    readonly description: string;
    /**
     * Getter for `listing_id`.
     */
    readonly listing_id: string;
    /**
     * Getter for `owner_pubky`.
     */
    readonly owner_pubky: string;
    /**
     * Getter for `title`.
     */
    readonly title: string;
}

/**
 * Physical condition of the listed item.
 */
export enum PubkyAppListingCondition {
    New = 0,
    LikeNew = 1,
    Excellent = 2,
    Good = 3,
    Fair = 4,
    ForParts = 5,
}

/**
 * Media attachment type.
 */
export enum PubkyAppListingMediaKind {
    Image = 0,
    Video = 1,
}

/**
 * Lifecycle state of a marketplace listing.
 */
export enum PubkyAppListingState {
    Active = 0,
    Paused = 1,
    Ended = 2,
    Removed = 3,
}

/**
 * Coarse public location attached to shops and listings.
 */
export class PubkyAppMarketplaceLocation {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
}

/**
 * Represents a marketplace review of a trade counterparty.
 *
 * URI: /pub/pubky.app/marketplace/v1/reviews/:review_id
 *
 * Example URI:
 *
 * `/pub/pubky.app/marketplace/v1/reviews/FPB0AM9S93Q3M1GFY1KV09GMQM`
 *
 * Where review_id is
 * Crockford-base32(Blake3("{reviewed_listing_uri}:{subject_pubky}:{role}")[:half])
 * and must match the record's `reviewId` field.
 */
export class PubkyAppMarketplaceReview {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyAppMarketplaceReview;
    toJson(): any;
    /**
     * Monotonically increasing record revision, starting at 1.
     */
    revision: bigint;
    /**
     * Marketplace contract version, always `1`.
     */
    schema_version: bigint;
    /**
     * Getter for `listing_id`.
     */
    readonly listing_id: string;
    /**
     * Getter for `subject_pubky`.
     */
    readonly subject_pubky: string;
    /**
     * Getter for `text`.
     */
    readonly text: string;
}

/**
 * Integer money in minor units, e.g. cents or satoshis.
 *
 * `amount_minor` is always an integer amount of the smallest unit,
 * `currency` is an uppercase asset code and `exponent` the number of
 * decimal places between minor and major units.
 */
export class PubkyAppMoney {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    amount_minor: bigint;
    exponent: bigint;
}

/**
 * Represents raw homeserver Mute object with timestamp
 * URI: /pub/pubky.app/mutes/:user_id
 *
 * Example URI:
 *
 * `/pub/pubky.app/mutes/pxnu33x7jtpx9ar1ytsi4yxbp6a5o36gwhffs8zoxmbuptici1jy`
 */
export class PubkyAppMute {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyAppMute;
    toJson(): any;
    created_at: bigint;
}

/**
 * Represents raw post in homeserver with content and kind
 * URI: /pub/pubky.app/posts/:post_id
 * Where post_id is CrockfordBase32 encoding of timestamp
 *
 * Example URI:
 *
 * `/pub/pubky.app/posts/00321FCW75ZFY`
 */
export class PubkyAppPost {
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyAppPost;
    /**
     * Creates a new `PubkyAppPost` instance and sanitizes it.
     */
    constructor(content: string, kind: PubkyAppPostKind, parent?: string | null, embed?: PubkyAppPostEmbed | null, attachments?: string[] | null);
    /**
     * Creates a new lockable `PubkyAppPost` instance and sanitizes it.
     */
    static new_with_lock(content: string, kind: PubkyAppPostKind, parent?: string | null, embed?: PubkyAppPostEmbed | null, attachments?: string[] | null, lock?: string | null): PubkyAppPost;
    toJson(): any;
    readonly attachments: string[] | undefined;
    readonly content: string;
    readonly embed: PubkyAppPostEmbed | undefined;
    readonly kind: string;
    readonly lock: string | undefined;
    readonly parent: string | undefined;
}

/**
 * Represents embedded content within a post
 */
export class PubkyAppPostEmbed {
    free(): void;
    [Symbol.dispose](): void;
    constructor(uri: string, kind: PubkyAppPostKind);
    readonly kind: string;
    readonly uri: string;
}

/**
 * Represents the type of pubky-app posted data
 * Used primarily to best display the content in UI
 */
export enum PubkyAppPostKind {
    Short = 0,
    Long = 1,
    Image = 2,
    Video = 3,
    Link = 4,
    File = 5,
    Collection = 6,
    Unknown = 7,
}

/**
 * Star ratings on a 1-5 integer scale. Only `overall` is required.
 */
export class PubkyAppReviewRatings {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    get communication(): bigint | undefined;
    set communication(value: bigint | null | undefined);
    get item_accuracy(): bigint | undefined;
    set item_accuracy(value: bigint | null | undefined);
    overall: bigint;
    get shipping(): bigint | undefined;
    set shipping(value: bigint | null | undefined);
}

/**
 * Which side of the trade the review covers.
 */
export enum PubkyAppReviewRole {
    BuyerReviewingSeller = 0,
    SellerReviewingBuyer = 1,
}

/**
 * Represents a seller's marketplace shop profile (singleton per user).
 *
 * URI: /pub/pubky.app/marketplace/v1/shop.json
 */
export class PubkyAppShop {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyAppShop;
    toJson(): any;
    /**
     * Monotonically increasing record revision, starting at 1.
     */
    revision: bigint;
    /**
     * Marketplace contract version, always `1`.
     */
    schema_version: bigint;
    vacation_mode: boolean;
    /**
     * Getter for `bio`.
     */
    readonly bio: string;
    /**
     * Getter for `name`.
     */
    readonly name: string;
    /**
     * Getter for `owner_pubky`.
     */
    readonly owner_pubky: string;
}

/**
 * Represents raw homeserver tag with id
 * URI: /pub/pubky.app/tags/:tag_id
 *
 * Example URI:
 *
 * `/pub/pubky.app/tags/FPB0AM9S93Q3M1GFY1KV09GMQM`
 *
 * Where tag_id is Crockford-base32(Blake3("{uri_tagged}:{label}")[:half])
 */
export class PubkyAppTag {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyAppTag;
    /**
     * Serialize to JSON for WASM.
     */
    toJson(): any;
    created_at: bigint;
    /**
     * Getter for `label`.
     */
    readonly label: string;
    /**
     * Getter for `uri`.
     */
    readonly uri: string;
}

/**
 * URI: /pub/pubky.app/profile.json
 */
export class PubkyAppUser {
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyAppUser;
    /**
     * Creates a new `PubkyAppUser` instance and sanitizes it.
     */
    constructor(name: string, bio?: string | null, image?: string | null, links?: PubkyAppUserLink[] | null, status?: string | null);
    toJson(): any;
    readonly bio: string | undefined;
    readonly image: string | undefined;
    readonly links: PubkyAppUserLink[] | undefined;
    readonly name: string;
    readonly status: string | undefined;
}

/**
 * Represents a user's single link with a title and URL.
 */
export class PubkyAppUserLink {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Creates a new `PubkyAppUserLink` instance and sanitizes it.
     */
    constructor(title: string, url: string);
    readonly title: string;
    readonly url: string;
}

/**
 * Represents user data with name, bio, image, links, and status.
 */
export class PubkyId {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
}

/**
 * Represents a user's single link with a title and URL.
 */
export class PubkySpecsBuilder {
    free(): void;
    [Symbol.dispose](): void;
    createBlob(blob_data: any): BlobResult;
    createBookmark(uri: string): BookmarkResult;
    /**
     * Creates a `kind = Collection` post — a curated list of URIs under
     * a name and optional description.
     *
     * Convenience wrapper around `createPost` that builds the
     * `PubkyAppCollectionContent` envelope (`{ name, description, items,
     * cover_image, layout }`) and JSON-serializes it into `content` internally,
     * so JS callers don't have to stringify the envelope themselves.
     *
     * `layout` is one of `"grid" | "list" | "visual"`.
     *
     * `parent` and `embed` are not supported for Collection posts — the
     * validator rejects them — so this helper omits those arguments.
     */
    createCollectionPost(name: string, description?: string | null, items?: string[] | null, cover_image?: string | null, layout?: string | null): PostResult;
    createFeed(tags: any, reach: string, layout: string, sort: string, content: string | null | undefined, name: string, domain_tags: any): FeedResult;
    createFile(name: string, src: string, content_type: string, size: number): FileResult;
    createFollow(followee_id: string): FollowResult;
    createLastRead(): LastReadResult;
    /**
     * Creates a listing record from a plain JSON object matching the
     * marketplace listing schema (camelCase fields). A fresh timestamp ID
     * is generated and written into the record's `listingId`.
     */
    createListing(listing: any): ListingResult;
    /**
     * Creates a marketplace review record from a plain JSON object matching
     * the marketplace review schema (camelCase fields). The hash ID is
     * derived from the reviewed listing URI, subject, and role, and written
     * into the record's `reviewId`.
     */
    createMarketplaceReview(review: any): MarketplaceReviewResult;
    createMute(mutee_id: string): MuteResult;
    /**
     * Optional `lock`: `pubky://` URL with a host pointing at a lock server.
     */
    createPost(content: string, kind: PubkyAppPostKind, parent?: string | null, embed?: PubkyAppPostEmbed | null, attachments?: string[] | null, lock?: string | null): PostResult;
    /**
     * Creates a shop record from a plain JSON object matching the
     * marketplace shop schema (camelCase fields).
     */
    createShop(shop: any): ShopResult;
    createTag(uri: string, label: string): TagResult;
    createUser(name: string, bio: string | null | undefined, image: string | null | undefined, links: any, status?: string | null): UserResult;
    /**
     * Edits an existing post by updating its content while preserving its original ID and timestamp.
     */
    editPost(original_post: PubkyAppPost, post_id: string, new_content: string): PostResult;
    /**
     * Creates a new `PubkyAppBuilder` instance.
     */
    constructor(pubky_id: string);
    /**
     * Returns validation limits as a JSON value for client-side use.
     */
    readonly validationLimits: any;
}

export class ShopResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly meta: Meta;
    readonly shop: PubkyAppShop;
}

export class TagResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly meta: Meta;
    readonly tag: PubkyAppTag;
}

export class UserResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly meta: Meta;
    readonly user: PubkyAppUser;
}

export function baseUriBuilder(user_id: string): string;

/**
 * Builds a Blob URI of the form "pubky://<author_id>/pub/pubky.app/blobs/<blob_id>"
 */
export function blobUriBuilder(author_id: string, blob_id: string): string;

/**
 * Builds a Bookmark URI of the form "pubky://<author_id>/pub/pubky.app/bookmarks/<bookmark_id>"
 */
export function bookmarkUriBuilder(author_id: string, bookmark_id: string): string;

/**
 * Builds a Feed URI of the form "pubky://<author_id>/pub/pubky.app/feeds/<feed_id>"
 */
export function feedUriBuilder(author_id: string, feed_id: string): string;

/**
 * Builds a File URI of the form "pubky://<author_id>/pub/pubky.app/files/<file_id>"
 */
export function fileUriBuilder(author_id: string, file_id: string): string;

/**
 * Builds a Follow URI of the form "pubky://<author_id>/pub/pubky.app/follows/<follow_id>"
 */
export function followUriBuilder(author_id: string, follow_id: string): string;

/**
 * Returns the list of valid MIME types for file attachments.
 *
 * This allows JavaScript consumers to validate file types before submission
 * without having to duplicate the list.
 *
 * # Example (TypeScript)
 *
 * ```typescript
 * import { get_valid_mime_types } from "pubky-app-specs";
 *
 * const validTypes = get_valid_mime_types();
 * const fileType = "image/png";
 * if (validTypes.includes(fileType)) {
 *   console.log("Valid file type!");
 * }
 * ```
 */
export function getValidMimeTypes(): any[];

/**
 * Each FFI function:
 * - Accepts minimal fields in a JavaScript-friendly manner (e.g. strings, JSON).
 * - Creates the Rust model, sanitizes, and validates it.
 * - Generates the ID (if applicable).
 * - Generates the path (if applicable).
 * - Returns { json, id, path, url } or a descriptive error.
 * Returns validation limits as a JSON value for client-side use without a builder.
 */
export function getValidationLimits(): any;

/**
 * Builds a LastRead URI of the form "pubky://<author_id>/pub/pubky.app/last_read"
 */
export function lastReadUriBuilder(author_id: string): string;

/**
 * Builds a Listing URI of the form "pubky://<seller_id>/pub/pubky.app/marketplace/v1/listings/<listing_id>"
 */
export function listingUriBuilder(seller_id: string, listing_id: string): string;

/**
 * Builds a MarketplaceReview URI of the form "pubky://<author_id>/pub/pubky.app/marketplace/v1/reviews/<review_id>"
 */
export function marketplaceReviewUriBuilder(author_id: string, review_id: string): string;

/**
 * Builds a Mute URI of the form "pubky://<author_id>/pub/pubky.app/mutes/<mute_id>"
 */
export function muteUriBuilder(author_id: string, mute_id: string): string;

/**
 * Parses a Pubky URI and returns a strongly typed `ParsedUriResult`.
 *
 * This function wraps the internal ParsedUri ust parsing logic. It converts the result into a
 * strongly typed object that is easier to use in TypeScript.
 *
 * # Parameters
 *
 * - `uri`: A string slice representing the Pubky URI. The URI should follow the format:
 *   `pubky://<user_id>/pub/pubky.app/<resource>[/<id>]`.
 *
 * # Returns
 *
 * On success, returns a `ParsedUriResult` with:
 * - `user_id`: the parsed user ID,
 * - `resource`: a string (derived from the Display implementation of internal `Resource` enum),
 * - `resource_id`: an optional resource identifier (if applicable).
 *
 * On failure, returns a JavaScript error (`String`) containing an error message.
 *
 * # Example (TypeScript)
 *
 * ```typescript
 * import { parse_uri } from "pubky-app-specs";
 *
 * try {
 *   const result = parse_uri("pubky://user123/pub/pubky.app/posts/abc123");
 *   console.log(result.user_id);        // e.g. "user123"
 *   console.log(result.resource);    // e.g. "posts"
 *   console.log(result.resource_id);      // e.g. "abc123" or null
 * } catch (error) {
 *   console.error("Error parsing URI:", error);
 * }
 * ```
 */
export function parse_uri(uri: string): ParsedUriResult;

/**
 * Builds a Post URI of the form "pubky://<author_id>/pub/pubky.app/posts/<post_id>"
 */
export function postUriBuilder(author_id: string, post_id: string): string;

/**
 * Builds a Shop URI of the form "pubky://<owner_id>/pub/pubky.app/marketplace/v1/shop.json"
 */
export function shopUriBuilder(owner_id: string): string;

/**
 * Builds a Tag URI of the form "pubky://<author_id>/pub/pubky.app/tags/<tag_id>"
 */
export function tagUriBuilder(author_id: string, tag_id: string): string;

/**
 * Builds an User URI of the form "pubky://<user_pubky_id>/pub/pubky.app/profile.json"
 */
export function userUriBuilder(user_id: string): string;
