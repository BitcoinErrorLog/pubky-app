const limits = require("./validationLimits.json");

const clone = () => JSON.parse(JSON.stringify(limits));

module.exports = {
validationLimits: limits,
getValidationLimits: clone,
default: limits,
};
